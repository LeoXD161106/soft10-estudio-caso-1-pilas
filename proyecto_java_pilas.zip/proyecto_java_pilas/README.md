# Analizador de expresiones aritméticas con pilas (Java)

Primer estudio de caso · SOFT-10 Estructuras de Datos · CENFOTEC · C3-2026

Programa en Java que usa una **pila implementada con nodos enlazados** (sin `java.util.Stack`)
para analizar expresiones aritméticas: valida paréntesis, convierte de notación infija a
postfija (algoritmo shunting-yard) y evalúa el resultado con variables.

## Clases
| Archivo | Descripción |
|---|---|
| `Token.java` | Token de la expresión (número, variable, operador o paréntesis). Inmutable. |
| `Nodo.java` | Nodo de la pila: guarda un `Token` y apunta al nodo de abajo. |
| `Pila.java` | Pila LIFO: `push`, `pop`, `peek`, `estaVacia`, `getTamano`, `vaciar`. |
| `AnalizadorExpresiones.java` | `tokenizar`, `validarParentesis`, `aPostfija`, `evaluar`. |
| `Main.java` | Rutina `main()` y `menu()` interactivo. |

## Cómo ejecutarlo
```bash
cd src
javac -encoding UTF-8 *.java
java Main
```
También puede abrirse la carpeta `src` en NetBeans, IntelliJ IDEA o Eclipse y ejecutar `Main`.

## Operadores soportados
`+  -  *  /  ^` y el menos unario (`-x`). Precedencia: `^` > menos unario > `* /` > `+ -`.
`^` y el menos unario se agrupan de derecha a izquierda.

## Ejemplos
| Expresión | Postfija | Resultado |
|---|---|---|
| `3 + 4 * (2 - 1)` | `3 4 2 1 - * +` | 7 |
| `(a + b) * c ^ 2` (a=2, b=3, c=4) | `a b + c 2 ^ *` | 80 |
| `-2^2` | `2 2 ^ neg` | -4 |
