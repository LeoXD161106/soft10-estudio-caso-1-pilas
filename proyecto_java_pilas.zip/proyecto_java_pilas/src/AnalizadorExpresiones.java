import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Funciones de análisis de expresiones aritméticas que usan la pila:
 * tokenización, validación de paréntesis, conversión de notación infija
 * a postfija (algoritmo shunting-yard) y evaluación de la notación postfija.
 */
public class AnalizadorExpresiones {

    private AnalizadorExpresiones() {
        // Clase de utilidades: no se instancia.
    }

    // ------------------------------------------------------------------
    // 1. Tokenización
    // ------------------------------------------------------------------

    /**
     * Divide el texto en tokens: números literales, variables, operadores
     * (+ - * / ^) y paréntesis. Detecta el menos unario según el contexto
     * (el '+' unario no está soportado).
     *
     * @throws IllegalArgumentException si hay caracteres no válidos
     */
    public static List<Token> tokenizar(String expresion) {
        List<Token> tokens = new ArrayList<>();
        int i = 0;
        int n = expresion.length();

        while (i < n) {
            char c = expresion.charAt(i);

            if (Character.isWhitespace(c)) {
                i++;
            } else if (Character.isDigit(c) || c == '.') {
                int inicio = i;
                int puntos = 0;
                while (i < n && (Character.isDigit(expresion.charAt(i)) || expresion.charAt(i) == '.')) {
                    if (expresion.charAt(i) == '.') {
                        puntos++;
                    }
                    i++;
                }
                String texto = expresion.substring(inicio, i);
                if (puntos > 1 || texto.equals(".")) {
                    throw new IllegalArgumentException("Número mal formado: '" + texto + "'");
                }
                tokens.add(Token.numero(texto));
            } else if (Character.isLetter(c) || c == '_') {
                int inicio = i;
                while (i < n && (Character.isLetterOrDigit(expresion.charAt(i)) || expresion.charAt(i) == '_')) {
                    i++;
                }
                tokens.add(Token.variable(expresion.substring(inicio, i)));
            } else if (c == '(') {
                tokens.add(Token.parentesisIzq());
                i++;
            } else if (c == ')') {
                tokens.add(Token.parentesisDer());
                i++;
            } else if (c == '-') {
                boolean posicionUnaria = tokens.isEmpty()
                        || tokens.get(tokens.size() - 1).getTipo() == Token.Tipo.OPERADOR
                        || tokens.get(tokens.size() - 1).getTipo() == Token.Tipo.PARENTESIS_IZQ;
                tokens.add(Token.operador(posicionUnaria ? Token.NEGATIVO_UNARIO : "-"));
                i++;
            } else if (c == '+' || c == '*' || c == '/' || c == '^') {
                tokens.add(Token.operador(String.valueOf(c)));
                i++;
            } else {
                throw new IllegalArgumentException("Carácter no válido: '" + c + "'");
            }
        }
        return tokens;
    }

    // ------------------------------------------------------------------
    // 2. Validación de paréntesis
    // ------------------------------------------------------------------

    /**
     * Verifica que los paréntesis estén balanceados usando una pila.
     * Cada '(' se apila y cada ')' desapila su pareja.
     *
     * @return null si están balanceados; de lo contrario, un mensaje de error
     */
    public static String validarParentesis(List<Token> tokens) {
        Pila pila = new Pila();
        int posicion = 0;

        for (Token token : tokens) {
            posicion++;
            if (token.getTipo() == Token.Tipo.PARENTESIS_IZQ) {
                pila.push(token);
            } else if (token.getTipo() == Token.Tipo.PARENTESIS_DER) {
                if (pila.estaVacia()) {
                    return "Paréntesis ')' sin pareja en el token #" + posicion;
                }
                pila.pop();
            }
        }
        if (!pila.estaVacia()) {
            return "Faltan " + pila.getTamano() + " paréntesis de cierre ')'";
        }
        return null;
    }

    // ------------------------------------------------------------------
    // 3. Conversión de infija a postfija (shunting-yard)
    // ------------------------------------------------------------------

    /**
     * Convierte la expresión infija a notación postfija. La pila guarda los
     * operadores y paréntesis que todavía esperan a sus operandos.
     *
     * @param traza si es true, imprime el estado de la pila en cada paso
     * @throws IllegalArgumentException si los paréntesis no están balanceados
     */
    public static List<Token> aPostfija(List<Token> tokens, boolean traza) {
        Pila operadores = new Pila();
        List<Token> salida = new ArrayList<>();

        if (traza) {
            System.out.printf("%-7s| %-34s| %-22s| %s%n",
                    "Token", "Acción", "Pila de operadores", "Salida");
            System.out.println("-".repeat(86));
        }

        for (Token token : tokens) {
            String accion;

            switch (token.getTipo()) {
                case NUMERO:
                case VARIABLE:
                    salida.add(token);
                    accion = "Operando: pasa a la salida";
                    break;

                case OPERADOR:
                    if (token.esUnario()) {
                        operadores.push(token);
                        accion = "Unario: push";
                    } else {
                        int retirados = 0;
                        while (!operadores.estaVacia()
                                && operadores.peek().getTipo() == Token.Tipo.OPERADOR
                                && (operadores.peek().precedencia() > token.precedencia()
                                || (operadores.peek().precedencia() == token.precedencia()
                                && !token.esAsociativoDerecha()))) {
                            salida.add(operadores.pop());
                            retirados++;
                        }
                        operadores.push(token);
                        accion = retirados == 0
                                ? "push"
                                : "pop x" + retirados + " a la salida, push";
                    }
                    break;

                case PARENTESIS_IZQ:
                    operadores.push(token);
                    accion = "push '('";
                    break;

                case PARENTESIS_DER:
                    while (!operadores.estaVacia()
                            && operadores.peek().getTipo() != Token.Tipo.PARENTESIS_IZQ) {
                        salida.add(operadores.pop());
                    }
                    if (operadores.estaVacia()) {
                        throw new IllegalArgumentException("Paréntesis ')' sin pareja");
                    }
                    operadores.pop(); // se descarta el '('
                    accion = "pop hasta '(' y descartarlo";
                    break;

                default:
                    throw new IllegalArgumentException("Token desconocido: " + token);
            }

            if (traza) {
                imprimirFila(token.getTexto(), accion, operadores, salida);
            }
        }

        while (!operadores.estaVacia()) {
            Token token = operadores.pop();
            if (token.getTipo() == Token.Tipo.PARENTESIS_IZQ) {
                throw new IllegalArgumentException("Paréntesis '(' sin cerrar");
            }
            salida.add(token);
        }
        if (traza) {
            imprimirFila("fin", "vaciar la pila hacia la salida", operadores, salida);
        }
        return salida;
    }

    private static void imprimirFila(String token, String accion, Pila pila, List<Token> salida) {
        System.out.printf("%-7s| %-34s| %-22s| %s%n", token, accion, pila, unir(salida));
    }

    /** Une una lista de tokens en un solo texto separado por espacios. */
    public static String unir(List<Token> tokens) {
        StringBuilder sb = new StringBuilder();
        for (Token token : tokens) {
            sb.append(token.getTexto()).append(' ');
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------
    // 4. Evaluación de la notación postfija
    // ------------------------------------------------------------------

    /**
     * Evalúa una expresión postfija con una pila de operandos: cada número
     * se apila y cada operador desapila sus operandos y apila el resultado.
     *
     * @param variables valores de las variables usadas en la expresión
     * @param traza     si es true, imprime la pila de operandos en cada paso
     * @throws IllegalArgumentException si la expresión está mal formada o
     *                                  falta el valor de una variable
     * @throws ArithmeticException      si hay una división entre cero
     */
    public static double evaluar(List<Token> postfija, Map<String, Double> variables, boolean traza) {
        Pila operandos = new Pila();

        if (traza) {
            System.out.printf("%-7s| %-30s| %s%n", "Token", "Acción", "Pila de operandos");
            System.out.println("-".repeat(70));
        }

        for (Token token : postfija) {
            String accion;

            switch (token.getTipo()) {
                case NUMERO:
                    operandos.push(token);
                    accion = "push " + token.getTexto();
                    break;

                case VARIABLE:
                    Double valor = variables.get(token.getTexto());
                    if (valor == null) {
                        throw new IllegalArgumentException(
                                "La variable '" + token.getTexto() + "' no tiene valor asignado");
                    }
                    operandos.push(Token.numero(valor));
                    accion = "push " + token.getTexto() + " = " + Token.formatear(valor);
                    break;

                case OPERADOR:
                    if (token.esUnario()) {
                        double a = sacarOperando(operandos);
                        operandos.push(Token.numero(-a));
                        accion = "pop 1, push -(" + Token.formatear(a) + ")";
                    } else {
                        double b = sacarOperando(operandos); // el segundo operando sale primero
                        double a = sacarOperando(operandos);
                        double resultado = operar(a, b, token.getTexto());
                        operandos.push(Token.numero(resultado));
                        accion = "pop 2, push " + Token.formatear(a) + " " + token.getTexto()
                                + " " + Token.formatear(b);
                    }
                    break;

                default:
                    throw new IllegalArgumentException("Token inesperado en postfija: " + token);
            }

            if (traza) {
                System.out.printf("%-7s| %-30s| %s%n", token.getTexto(), accion, operandos);
            }
        }

        if (operandos.getTamano() != 1) {
            throw new IllegalArgumentException(
                    "Expresión mal formada: sobran o faltan operandos/operadores");
        }
        return operandos.pop().getValor();
    }

    private static double sacarOperando(Pila pila) {
        try {
            return pila.pop().getValor();
        } catch (IllegalStateException e) {
            throw new IllegalArgumentException("Expresión mal formada: falta un operando");
        }
    }

    private static double operar(double a, double b, String operador) {
        switch (operador) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                if (b == 0) {
                    throw new ArithmeticException("División entre cero");
                }
                return a / b;
            case "^":
                return Math.pow(a, b);
            default:
                throw new IllegalArgumentException("Operador desconocido: " + operador);
        }
    }
}
