/**
 * Nodo de la pila enlazada. Cada nodo guarda un token de la expresión
 * y una referencia al nodo que está justo debajo de él en la pila.
 */
public class Nodo {

    private final Token dato;
    private Nodo siguiente;

    public Nodo(Token dato, Nodo siguiente) {
        this.dato = dato;
        this.siguiente = siguiente;
    }

    public Token getDato() { return dato; }

    public Nodo getSiguiente() { return siguiente; }

    public void setSiguiente(Nodo siguiente) { this.siguiente = siguiente; }
}
