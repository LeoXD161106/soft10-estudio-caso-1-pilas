import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Representa un token (unidad léxica) de una expresión aritmética.
 * Un token puede ser un número literal, una variable numérica,
 * un operador o un paréntesis.
 *
 * La clase es inmutable: una vez creado un token no se modifica.
 */
public class Token {

    /** Categorías de token que reconoce el analizador. */
    public enum Tipo { NUMERO, VARIABLE, OPERADOR, PARENTESIS_IZQ, PARENTESIS_DER }

    /** Texto con el que se representa internamente el menos unario (ej.: -5). */
    public static final String NEGATIVO_UNARIO = "neg";

    private final Tipo tipo;
    private final String texto;
    private final double valor; // solo tiene sentido si el tipo es NUMERO

    private Token(Tipo tipo, String texto, double valor) {
        this.tipo = tipo;
        this.texto = texto;
        this.valor = valor;
    }

    // ----------------------- Fábricas de tokens -----------------------

    public static Token numero(double valor) {
        return new Token(Tipo.NUMERO, formatear(valor), valor);
    }

    public static Token numero(String texto) {
        return new Token(Tipo.NUMERO, texto, Double.parseDouble(texto));
    }

    public static Token variable(String nombre) {
        return new Token(Tipo.VARIABLE, nombre, 0);
    }

    public static Token operador(String simbolo) {
        return new Token(Tipo.OPERADOR, simbolo, 0);
    }

    public static Token parentesisIzq() {
        return new Token(Tipo.PARENTESIS_IZQ, "(", 0);
    }

    public static Token parentesisDer() {
        return new Token(Tipo.PARENTESIS_DER, ")", 0);
    }

    // ----------------------- Consultas -----------------------

    public Tipo getTipo() { return tipo; }

    public String getTexto() { return texto; }

    public double getValor() { return valor; }

    /** Indica si el token es el operador de menos unario. */
    public boolean esUnario() {
        return tipo == Tipo.OPERADOR && texto.equals(NEGATIVO_UNARIO);
    }

    /**
     * Precedencia del operador: a mayor número, se evalúa primero.
     * Devuelve 0 si el token no es un operador.
     */
    public int precedencia() {
        if (tipo != Tipo.OPERADOR) {
            return 0;
        }
        switch (texto) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case NEGATIVO_UNARIO:
                return 3;
            case "^":
                return 4;
            default:
                return 0;
        }
    }

    /** La potencia y el menos unario se agrupan de derecha a izquierda. */
    public boolean esAsociativoDerecha() {
        return texto.equals("^") || esUnario();
    }

    /** Convierte un número a texto sin ceros innecesarios (3.0 -> "3"). */
    public static String formatear(double valor) {
        if (Double.isNaN(valor) || Double.isInfinite(valor)) {
            return String.valueOf(valor);
        }
        return new BigDecimal(valor)
                .setScale(8, RoundingMode.HALF_UP)
                .stripTrailingZeros()
                .toPlainString();
    }

    @Override
    public String toString() {
        return texto;
    }
}
