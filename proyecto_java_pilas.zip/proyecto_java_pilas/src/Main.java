import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Programa principal: ofrece un menú interactivo para analizar expresiones
 * aritméticas con una pila (validar paréntesis, convertir a postfija y evaluar).
 */
public class Main {

    private static final Scanner ENTRADA = new Scanner(System.in);
    private static final Map<String, Double> variables = new LinkedHashMap<>();
    private static String expresionActual = null;

    public static void main(String[] args) {
        menu();
        System.out.println("\n¡Hasta pronto!");
    }

    // ------------------------------------------------------------------
    // Menú principal
    // ------------------------------------------------------------------

    /** Muestra el menú en un ciclo hasta que el usuario elija salir. */
    private static void menu() {
        int opcion;
        do {
            mostrarOpciones();
            opcion = leerEntero("Seleccione una opción: ");
            System.out.println();

            switch (opcion) {
                case 1:
                    ingresarExpresion();
                    break;
                case 2:
                    validarParentesis();
                    break;
                case 3:
                    verTokens();
                    break;
                case 4:
                    convertirAPostfija();
                    break;
                case 5:
                    definirVariable();
                    break;
                case 6:
                    verVariables();
                    break;
                case 7:
                    evaluarExpresion();
                    break;
                case 8:
                    modoManual();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            if (opcion != 0) {
                pausa();
            }
        } while (opcion != 0);
    }

    private static void mostrarOpciones() {
        System.out.println("\n==================================================");
        System.out.println("   ANALIZADOR DE EXPRESIONES ARITMÉTICAS (PILAS)");
        System.out.println("==================================================");
        System.out.println("  Expresión actual: " + (expresionActual == null ? "(ninguna)" : expresionActual));
        System.out.println("--------------------------------------------------");
        System.out.println("  1. Ingresar o cambiar la expresión");
        System.out.println("  2. Validar paréntesis balanceados");
        System.out.println("  3. Ver los tokens de la expresión");
        System.out.println("  4. Convertir a notación postfija (con traza)");
        System.out.println("  5. Definir el valor de una variable");
        System.out.println("  6. Ver variables definidas");
        System.out.println("  7. Evaluar la expresión");
        System.out.println("  8. Modo manual: probar la pila (push/pop/peek)");
        System.out.println("  0. Salir");
        System.out.println("--------------------------------------------------");
    }

    // ------------------------------------------------------------------
    // Opciones del menú
    // ------------------------------------------------------------------

    private static void ingresarExpresion() {
        System.out.println("Ejemplos: 3 + 4 * (2 - 1)   |   (a + b) * c ^ 2   |   -x + 10 / 4");
        System.out.print("Escriba la expresión: ");
        String texto = ENTRADA.nextLine().trim();

        if (texto.isEmpty()) {
            System.out.println("La expresión no puede estar vacía.");
            return;
        }
        try {
            AnalizadorExpresiones.tokenizar(texto); // solo para validar los caracteres
            expresionActual = texto;
            System.out.println("Expresión guardada correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void validarParentesis() {
        if (!hayExpresion()) {
            return;
        }
        try {
            List<Token> tokens = AnalizadorExpresiones.tokenizar(expresionActual);
            String error = AnalizadorExpresiones.validarParentesis(tokens);
            System.out.println(error == null
                    ? "Los paréntesis están balanceados."
                    : "Paréntesis NO balanceados: " + error);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void verTokens() {
        if (!hayExpresion()) {
            return;
        }
        try {
            List<Token> tokens = AnalizadorExpresiones.tokenizar(expresionActual);
            System.out.println("Tokens (" + tokens.size() + "):");
            for (Token token : tokens) {
                System.out.printf("  %-7s -> %s%n", token.getTexto(), token.getTipo());
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void convertirAPostfija() {
        if (!hayExpresion()) {
            return;
        }
        try {
            List<Token> tokens = AnalizadorExpresiones.tokenizar(expresionActual);
            List<Token> postfija = AnalizadorExpresiones.aPostfija(tokens, true);
            System.out.println("\nNotación postfija: " + AnalizadorExpresiones.unir(postfija));
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void definirVariable() {
        System.out.print("Nombre de la variable (ej.: x): ");
        String nombre = ENTRADA.nextLine().trim();

        if (!nombre.matches("[A-Za-z_][A-Za-z0-9_]*")) {
            System.out.println("Nombre no válido: use letras, dígitos o '_' y no empiece con dígito.");
            return;
        }
        double valor = leerDecimal("Valor de " + nombre + ": ");
        variables.put(nombre, valor);
        System.out.println(nombre + " = " + Token.formatear(valor));
    }

    private static void verVariables() {
        if (variables.isEmpty()) {
            System.out.println("No hay variables definidas.");
            return;
        }
        System.out.println("Variables definidas:");
        for (Map.Entry<String, Double> entrada : variables.entrySet()) {
            System.out.println("  " + entrada.getKey() + " = " + Token.formatear(entrada.getValue()));
        }
    }

    private static void evaluarExpresion() {
        if (!hayExpresion()) {
            return;
        }
        try {
            List<Token> tokens = AnalizadorExpresiones.tokenizar(expresionActual);

            String error = AnalizadorExpresiones.validarParentesis(tokens);
            if (error != null) {
                System.out.println("No se puede evaluar. " + error);
                return;
            }
            pedirVariablesFaltantes(tokens);

            List<Token> postfija = AnalizadorExpresiones.aPostfija(tokens, false);
            System.out.println("Postfija: " + AnalizadorExpresiones.unir(postfija));

            System.out.print("¿Mostrar la traza de la pila paso a paso? (s/n): ");
            boolean traza = ENTRADA.nextLine().trim().equalsIgnoreCase("s");
            System.out.println();

            double resultado = AnalizadorExpresiones.evaluar(postfija, variables, traza);
            System.out.println("\nResultado: " + expresionActual + " = " + Token.formatear(resultado));
        } catch (ArithmeticException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /** Solicita el valor de cada variable de la expresión que aún no esté definida. */
    private static void pedirVariablesFaltantes(List<Token> tokens) {
        for (Token token : tokens) {
            if (token.getTipo() == Token.Tipo.VARIABLE && !variables.containsKey(token.getTexto())) {
                double valor = leerDecimal("La variable '" + token.getTexto() + "' no tiene valor. Ingréselo: ");
                variables.put(token.getTexto(), valor);
            }
        }
    }

    /** Permite experimentar directamente con las operaciones básicas de la pila. */
    private static void modoManual() {
        Pila pila = new Pila();
        int opcion;
        do {
            System.out.println("--- Modo manual de la pila ---");
            System.out.println("Pila actual (base -> cima): " + pila);
            System.out.println("  1. push (apilar un token)");
            System.out.println("  2. pop (desapilar)");
            System.out.println("  3. peek (ver la cima)");
            System.out.println("  4. ¿Está vacía?");
            System.out.println("  5. Tamaño");
            System.out.println("  6. Vaciar");
            System.out.println("  0. Volver al menú principal");
            opcion = leerEntero("Opción: ");

            try {
                switch (opcion) {
                    case 1:
                        System.out.print("Token(s) a apilar (ej.: 5, x, +, (): ");
                        for (Token token : AnalizadorExpresiones.tokenizar(ENTRADA.nextLine())) {
                            pila.push(token);
                        }
                        break;
                    case 2:
                        System.out.println("pop -> " + pila.pop());
                        break;
                    case 3:
                        System.out.println("peek -> " + pila.peek());
                        break;
                    case 4:
                        System.out.println(pila.estaVacia() ? "Sí, la pila está vacía." : "No, la pila tiene elementos.");
                        break;
                    case 5:
                        System.out.println("Tamaño: " + pila.getTamano());
                        break;
                    case 6:
                        pila.vaciar();
                        System.out.println("Pila vaciada.");
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (IllegalStateException | IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
            System.out.println();
        } while (opcion != 0);
    }

    // ------------------------------------------------------------------
    // Utilidades de entrada
    // ------------------------------------------------------------------

    private static boolean hayExpresion() {
        if (expresionActual == null) {
            System.out.println("Primero ingrese una expresión (opción 1).");
            return false;
        }
        return true;
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(ENTRADA.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número entero.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Double.parseDouble(ENTRADA.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número válido (ej.: 4 o 2.5).");
            }
        }
    }

    private static void pausa() {
        System.out.print("\nPresione Enter para continuar...");
        ENTRADA.nextLine();
    }
}
