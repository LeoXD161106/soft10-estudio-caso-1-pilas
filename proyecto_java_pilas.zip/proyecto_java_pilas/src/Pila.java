/**
 * Pila (estructura LIFO) implementada con nodos enlazados.
 * Solo se puede acceder a la cima: el último token que entra es el
 * primero que sale. Todas las operaciones básicas son O(1).
 */
public class Pila {

    private Nodo cima;
    private int tamano;

    public Pila() {
        this.cima = null;
        this.tamano = 0;
    }

    /** Apila un token en la cima. */
    public void push(Token token) {
        if (token == null) {
            throw new IllegalArgumentException("No se puede apilar un token nulo");
        }
        cima = new Nodo(token, cima);
        tamano++;
    }

    /**
     * Desapila y devuelve el token de la cima.
     * @throws IllegalStateException si la pila está vacía (subdesbordamiento)
     */
    public Token pop() {
        if (estaVacia()) {
            throw new IllegalStateException("La pila está vacía");
        }
        Token dato = cima.getDato();
        cima = cima.getSiguiente();
        tamano--;
        return dato;
    }

    /**
     * Devuelve el token de la cima sin retirarlo.
     * @throws IllegalStateException si la pila está vacía
     */
    public Token peek() {
        if (estaVacia()) {
            throw new IllegalStateException("La pila está vacía");
        }
        return cima.getDato();
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public int getTamano() {
        return tamano;
    }

    /** Elimina todos los elementos de la pila. */
    public void vaciar() {
        cima = null;
        tamano = 0;
    }

    /** Muestra la pila de la base hacia la cima, por ejemplo: [ ( + * ]. */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Nodo actual = cima; actual != null; actual = actual.getSiguiente()) {
            sb.insert(0, actual.getDato().getTexto() + " ");
        }
        return "[ " + sb + "]";
    }
}
